package com.sample.spring5webapp_v01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5webappV01Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring5webappV01Application.class, args);
	}

}
