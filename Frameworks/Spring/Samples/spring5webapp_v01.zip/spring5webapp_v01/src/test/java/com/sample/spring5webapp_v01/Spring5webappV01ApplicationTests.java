package com.sample.spring5webapp_v01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5webappV01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
